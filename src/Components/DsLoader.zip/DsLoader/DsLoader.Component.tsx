import React, { FC } from 'react'

import { DsLoaderProps, LOADER_MAP } from './DsLoader.Types'
import { SystemStyleObject } from '@mui/system'
import { DsBackdrop } from '../DsBackdrop'
import { DsBox } from '../DsBox'
import { Theme } from '@mui/material'

export const DsLoader: FC<DsLoaderProps> = props => {
  const {
    'ds-variant': loaderVariant = 'threeDot',
    color,
    position,
    backdrop,
    BackdropProps,
    ...boxProps
  } = props

  const LoaderElement = LOADER_MAP[loaderVariant]
  const { sx: wrapperStyleProps, ...restBoxProps } = boxProps
  return (
    <DsBackdrop {...BackdropProps} open={true} invisible={!backdrop}>
      <DsBox
        sx={[
          {
            position,
            color: `var(--ds-colour-${color}, var(--ds-colour-dotLoader))`
          },
          backdrop
            ? {
                color: `var(--ds-colour-${color}, var(--palette-common-white))`
              }
            : {},
          {
            color: color
          },
          {
            maxHeight: '100px',
            maxWidth: '100px',
            ...((wrapperStyleProps as SystemStyleObject<Theme>) || {})
          }
        ]}
        {...restBoxProps}
      >
        <LoaderElement />
      </DsBox>
    </DsBackdrop>
  )
}
